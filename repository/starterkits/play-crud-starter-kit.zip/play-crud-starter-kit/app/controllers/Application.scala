package controllers

import java.util.Date

import com.couchbase.client.protocol.views.Query
import org.joda.time.DateTime
import org.reactivecouchbase.play.PlayCouchbase
import play.api.Play.current
import play.api.libs.concurrent.Execution.Implicits.defaultContext
import play.api.libs.json._
import play.api.mvc.{Action, Controller}

import scala.util.{Failure, Success, Try}

object Application extends Controller {

  def bucket = PlayCouchbase.bucket("default")

  def searchRaw = Action.async {
    bucket.rawSearch("users", "by_name")(new Query().setLimit(1)).headOption.map { opt =>
      println(opt)
      opt.map(row => Json.parse(row.value)) // value is a string, need to parse it
    }.map {
      case Some(doc) => Ok(doc)
      case None => NotFound
    }
  }

  def searchTyped = Action.async {
    import org.reactivecouchbase.CouchbaseRWImplicits.documentAsJsValuetReader
    // here you need setIncludeDocs(true) because search will try to validate documents with the implicit reader
    bucket.search("users", "by_name")(new Query().setIncludeDocs(true).setLimit(1)).headOption.map { opt =>
      opt.map(row => Json.parse(row.value)) // value is a string, need to parse it
    }.map {
      case Some(doc) => Ok(doc)
      case None => NotFound
    }
  }
}